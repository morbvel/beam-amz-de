package com.beamsuntory.amz.de.commons

import org.apache.spark.sql.Column
import org.apache.spark.sql.functions.{col, substring, trim, when}

object CommonsAmzDE  {




}
